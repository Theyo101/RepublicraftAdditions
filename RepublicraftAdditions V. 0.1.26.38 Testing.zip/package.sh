#!/usr/bin/env bash
set -Eeuo pipefail
  boldBlue='\033[1;34m'
  boldRED='\033[1;31m'
  resetColor='\033[0m'

  majorMinor=$(cat currentversion.txt)
  echo -e "${boldBlue}Major Minor is $majorMinor"
  
  formattedDate=$(date +%y.%V)
  echo -e "Date Code is $formattedDate"
  
  fullVersion="$majorMinor.$formattedDate"
  echo -e "Full Version is $fullVersion \n${resetColor}"

if test -f RepublicraftAdditions\ V.\ $majorMinor[.]*Testing.zip; then
  echo -e "${boldRED}DELETING CURRENT TESTING VERSIONS${resetColor}"
  rm -vI RepublicraftAdditions\ V.\ $majorMinor[.]*Testing.zip;
  zip -x *.sh, *.txt -r "RepublicraftAdditions V. $fullVersion Testing.zip" ./*;
else
  zip -x .sh, *.txt -r "RepublicraftAdditions V. $fullVersion Testing.zip" ./*
fi
